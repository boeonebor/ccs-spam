<?php

header("Location: https://www.bforbank.com/compte-bancaire/");

?>